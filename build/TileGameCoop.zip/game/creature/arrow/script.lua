function timer( id, time)

end

function signal( id, fromId, data)
end

function vertexhit( id)
end
