function vertexhit( id)
end

function start( id) 
	setSolid( id, true)
end

function destroy( id)
	delete( id)
end
