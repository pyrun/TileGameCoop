function start( id)
	setAnimation( id, "present" .. tostring(math.random ( 0, 5)))
end
