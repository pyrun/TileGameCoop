function start( id)
	setPosition( id, 90, 10)
end