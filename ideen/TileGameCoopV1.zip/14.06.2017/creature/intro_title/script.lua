function vertexhit( id)
end

