function timer( id, time)
	if getAmountPlayerActive() == getAmountPlayerChamps() then
		if getAmountPlayerActive() > 0 then
			end_level( false)
		end
	end
end

function collision( id, ...)
	
end
