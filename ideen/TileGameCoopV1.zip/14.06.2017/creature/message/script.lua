function vertexhit( id)
end

function start( id) 
	global_value = "Test"
end

function timer( id) 
	message( id, 1, 0, 0, global_value)
end
