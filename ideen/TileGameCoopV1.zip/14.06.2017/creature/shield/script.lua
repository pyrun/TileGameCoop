function action_idle( id)
	delete( id)
end

function start( id) 
	setAnimation( id, "open")
end

function action_open( id) 
	setAnimation( id, "idle")
end

function collision( id, ...)

end


