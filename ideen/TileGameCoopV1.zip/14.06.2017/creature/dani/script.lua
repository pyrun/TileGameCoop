package.path = package.path .. ";creature/human/?.lua"
require( "script")
