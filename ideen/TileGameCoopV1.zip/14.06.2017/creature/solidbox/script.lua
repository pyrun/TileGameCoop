function timer( id) 
	setAnimation( id, "free")
end
